var today = new Date();
var msg = "Te indico la fecha y hora actual: " + today.toLocaleString();
alert(msg);