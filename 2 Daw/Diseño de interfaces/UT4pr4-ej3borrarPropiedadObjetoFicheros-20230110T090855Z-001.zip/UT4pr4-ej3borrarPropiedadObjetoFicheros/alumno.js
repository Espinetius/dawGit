  let alumno =  [
  {
  nombre : "David Perez", 
  grupo : "DAW2", 
  fct : "no"  
  }, 
  {
  nombre : "Ana Garcia",
  grupo : "DAW2",
  fct : "si"  
  },
  {
  nombre : "Gema Perez",
  grupo: "ASIR2",
  fct : "no"
  }
  ]