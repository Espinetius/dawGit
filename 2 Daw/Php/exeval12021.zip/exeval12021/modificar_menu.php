<?php
    include_once("claseConexionBD.php");
    session_start();

    if(!isset($_SESSION["usuario"])  || $_SESSION["rol"] == "rrhh"  || $_SESSION["rol"] == "fin")
    {
        header("Location: login.php");
    }
    
    echo "Conectado como " . $_SESSION["nombre"] . " " . $_SESSION["apellidos"];

    $usuario = $_GET["usuario"];

    if(isset($_POST["modificar"]))
    {
        $nombre = $_POST["nombre"];
        $apellidos = $_POST["apellidos"];
        $contrasenia = $_POST["contrasenia"];

        $bd = new ConectarBD();
        $base = $bd->getConexion();

        $resultado = $base->prepare("UPDATE usuarios SET password = :contrasenia , nombre = :nombre , apellidos = :apellidos WHERE usuario = :usuario");
        $resultado->execute(array("contrasenia" => $contrasenia, "nombre" => $nombre, "apellidos" => $apellidos ,"usuario" => $usuario));
        $resultado->setFetchMode(PDO::FETCH_ASSOC);
        
        if($resultado->rowCount() > 0)
        {
            $validacion = "Se ha modificado correctamente";
        }   
        else
        {
            $validacion = "No se ha modificado";
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar</title>
</head>
<body>
    <form action="" method="POST">
        Nombre <input type="text" name="nombre">
        <br><br>
        Apellidos <input type="text" name="apellidos">
        <br><br>
        Contraseña <input type="text" name="contrasenia">
        <br><br>
        <input type="submit" value="Modificar" name="modificar">
    </form>
    <p><a href="admin.php">Regresar menu anterior</a></p>
    <p><a href="cerrarSesion.php">Cerrar sesion</a></p>
    <p style="color: red;"><?php if(isset($validacion)) echo $validacion ?></p>
</body>
</html>