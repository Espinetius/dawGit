<?php

    define('HOST', 'localhost');
    define('BD', 'exeval1');
    define('USER', 'dwes');
    define('PASSWORD', 'dwes');
    define('CHARSET', 'utf8');

?>