<?php
    include_once("claseConexionBD.php");

    session_start();

    $errorValidacion = "";
    $errorUsuario = "";
    $errorContrasenia = "";

    if(isset($_POST["entrar"]))
    {
        $usuario = $_POST["usuario"];
        $contrasenia = $_POST["contrasenia"];

        if(empty($usuario))
        {
            $errorUsuario = "Debe introducir el usuario";
        }

        if(empty($contrasenia))
        {
            $errorContrasenia = "Debe introducir la contraseña";
        }

        if(!empty($usuario) && !empty($contrasenia))
        {
            $bd = new ConectarBD();
            $base = $bd->getConexion();

            $resultado = $base->prepare("SELECT * FROM usuarios WHERE usuario = :usuario AND password = :contrasenia");
            $resultado->execute(array("usuario" => $usuario, "contrasenia" => $contrasenia));
            $resultado->setFetchMode(PDO::FETCH_ASSOC);
            $filaUsuario = $resultado->fetch();

            if($resultado->rowCount() > 0)
            {
                $_SESSION["usuario"] = $filaUsuario["usuario"];
                $_SESSION["nombre"] = $filaUsuario["nombre"];
                $_SESSION["apellidos"] = $filaUsuario["apellidos"];
                $_SESSION["rol"] = $filaUsuario["rol"];

                if($filaUsuario["rol"] == "admin")
                {
                    header("Location: admin.php");
                }
                else if($filaUsuario["rol"] == "rrhh")
                {
                    header("Location: rrhh.php");
                }
                else if($filaUsuario["rol"] == "fin")
                {
                    header("Location: finanzas.php");
                }
            }
            else
            {
                $errorValidacion = "Usuario o contraseña incorrecto";
            }

        }
       
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Login</h1>
    <form action="" method="POST">
        Usuario <input type="text" name="usuario">
        <br><br>
        Contrasenia <input type="text" name="contrasenia">
        <br><br>
        <input type="submit" value="Entrar" name="entrar">
    </form>
    <p style="color: red;"><?php if(isset($errorValidacion)) echo $errorValidacion  ?></p>
    <p style="color: red;"><?php if(isset($errorUsuario)) echo $errorUsuario  ?></p>
    <p style="color: red;"><?php if(isset($errorContrasenia)) echo $errorContrasenia  ?></p>
</body>
</html>