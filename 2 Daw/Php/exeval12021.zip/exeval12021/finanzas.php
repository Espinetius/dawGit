<?php
    session_start();

    if(!isset($_SESSION["usuario"]) || $_SESSION["rol"] == "rrhh")
    {
        header("Location: login.php");
    }

    echo "Conectado como " . $_SESSION["nombre"] . " " . $_SESSION["apellidos"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finanzas</title>
</head>
<body>
    <h1>Finanzas</h1>
    <p><a href="cerrarSesion.php">Cerrar sesion</a></p>
</body>
</html>