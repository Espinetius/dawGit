<?php

    include_once("claseConexionBD.php");
    session_start();

    if(!isset($_SESSION["usuario"])  || $_SESSION["rol"] == "rrhh"  || $_SESSION["rol"] == "fin")
    {
        header("Location: login.php");
    }
     
    echo "Conectado como " . $_SESSION["nombre"] . " " . $_SESSION["apellidos"];

    $bd = new ConectarBD();
    $base = $bd->getConexion();

    $resultado = $base->prepare("SELECT * FROM usuarios");
    $resultado->execute();
    $resultado->setFetchMode(PDO::FETCH_ASSOC);
    $usuarios = $resultado->fetchAll();

    $tabla = "<table border=1>";
    $tabla .= "<tr>";
    $tabla .= "<th>Usuario</th><th>Rol</th><th>Nombre</th><th>Apellidos</th>";
    $tabla .= "</tr>";
    foreach($usuarios as $v)
    {
        $tabla .= "<tr>";
        $tabla .= "<td>" . $v["usuario"] . "</td><td>" . $v["rol"] . "</td><td>" . $v["nombre"] . "</td><td>" . $v["apellidos"] . "</td><td><a href='modificar_menu.php?usuario=". $v["usuario"] . "'>Modificar</a></td>";
        $tabla .= "</tr>";
    }
    $tabla .= "</table>";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas</title>
</head>
<body>
    <h2>Relacion de usuarios</h2>
    <div><?php echo $tabla ?></div>
    <p><a href="admin.php">Regresar menu anterior</a></p>
    <p><a href="cerrarSesion.php">Cerrar sesion</a></p>
</body>
</html>