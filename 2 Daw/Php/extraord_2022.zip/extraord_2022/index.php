<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página inicial</title>
</head>
<body>
    <a href="aplicacion.php">1-Entrar a Aplicación</a><br/>
    <a href="login.php">2-Login</a><br/>
    <a href="registro.php">3-Registro</a>
</body>
</html>