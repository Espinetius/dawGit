<?php
include_once("usuarios.php");

session_start();

$error = "";
/*$errUsu="";
$errClave="";*/


$selectUsuarios="<select name='usuario'>";
foreach ($credenciales as $c) { 
    $selectUsuarios.= "<option>".$c["usuario"]."</option>";
}
$selectUsuarios.="</select>";

$selectClaves="<select name='clave'>";
foreach ($credenciales as $c) { 
    $selectClaves.= "<option>".$c["clave"]."</option>";
}
$selectClaves.="</select>";



if (isset($_POST['enviar'])) {
    /*if(empty($_POST["usuario"])){
        $errUsu = "Debe introducir usuario";}
    if(empty($_POST["clave"])){
        $errClave = "Debe introducir clave";}*/
    
    if(!empty($_POST["usuario"]) && !empty($_POST["clave"])){
        $valido = checkCred ($_POST["usuario"], $_POST["clave"],$credenciales);
        if(!$valido){
            $error = "Par usuario/contreña no validos";
        }else{
            $_SESSION['usuario'] = $_POST['usuario'];
            header('Location: aplicacion.php');
        }
    }
}

function checkCred($pUsuario, $pClave, $credenciales){
    $check=false;
    foreach($credenciales as $datosUsu){
        if($pUsuario== $datosUsu["usuario"] && $pClave==$datosUsu["clave"]){
            $check=true;
            break;
        }
    }
    return $check;
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <h2>Login</h2>
    <form action="" method="post">
        Usuario: <?php echo $selectUsuarios;?>
        Clave: <?php echo $selectClaves;?>
        <input type="submit" value="Enviar" name="enviar" />
    </form>
    <br />
    <p>
        <?php echo $error; ?>
        <!-- <?php /*echo $errUsu; ?>
        <?php echo $errClave; */?> -->
    </p>
</body>

</html>