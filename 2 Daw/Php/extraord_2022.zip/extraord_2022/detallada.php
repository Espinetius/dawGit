<?php
    session_start();

    echo "ID: ".$_GET['id']."<br>";
    echo "NOMBRE: ".$_GET['nom']."<br>";
    echo "AÑO: ".$_GET['anio']."<br>";
    echo "<img src='./img/".$_GET['img']."' style='width:100px; heigth:100px'/><br>";

    echo "<a href='index.php'>Ir a Inicio</a><br/>";
    echo "<a href='aplicacion.php'>Regresar menú anterior</a><br/>";
    if (isset( $_SESSION['usuario'])) {
      echo "<a href='cerrarsesion.php'>Cerrar Sesión</a><br>";
      echo "Conectado como " . $_SESSION['usuario'];
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle</title>
</head>
<body>    
</body>
</html>