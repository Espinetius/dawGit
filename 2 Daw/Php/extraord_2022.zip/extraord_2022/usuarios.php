<?php

 $credenciales = array(
    array('usuario' => 'Ana', 'clave' => 'c1'),
    array('usuario' => 'Jose', 'clave' => 'c2'),
    array('usuario' => 'Ok', 'clave' => 'Ok'),
    array('usuario' => 'Antonio', 'clave' => 'c4')
  );
?>

