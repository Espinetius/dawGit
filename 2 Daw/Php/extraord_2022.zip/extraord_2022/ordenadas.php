<?php
    session_start();
    $haySession=isset( $_SESSION['usuario']);
    if ($haySession) {
        echo "Conectado como " . $_SESSION['usuario'];
    }

    $datos = obtener_datos();
    foreach ($datos as $fila) {
        $anio[]=$fila['anio'];
        }
        array_multisort($anio, SORT_ASC, $datos);
    if ( count($datos) > 0 ) {
    ?>    
        <table border="5">
        <?php
            if (!$haySession)      
                echo"<tr><th>BUENO</th><th>LO</th><th>VAMOS</th><th>VIENDO</th></tr>";
            else
                echo"<tr><th>BUENO</th><th>LO</th><th>VAMOS</th><th>VIENDO</th><th colspan='2'>SI ESO</th></tr>";

            foreach ( $datos as $d ) {
                echo '<tr>';
        
                echo "<td>".$d['id']."</td><td>".$d['nombre']."</td><td>".$d['anio']."</td><td><a href='detallada.php?id=".$d['id']."&nom=".$d['nombre']."&anio=".$d['anio']."&img=".$d['caratula']."'><img src='./img/".$d['caratula']."' style='width:100px; heigth:100px'/></a></td>";
            
                if ($haySession) {
                    echo '<td><a href="modificar.php?id='.$d['id'].'&nom='.$d['nombre'].'&anio='.$d['anio'].'&img='.$d['caratula'].'&boton=Modificar">Modificar</a></td>';
                    echo '<td><a href="modificar.php?id='.$d['id'].'&nom='.$d['nombre'].'&anio='.$d['anio'].'&img='.$d['caratula'].'&boton=Eliminar">Eliminar</a></td>';
                }             

                echo "</tr>";
            }
        ?>      
        </table>          
        <br/>
    <?php    
    }
    else {
        echo "No hay datos";
    }

 function obtener_datos() {
    
    include_once 'claseConexionBD.php';
    
    $BD = new ConectarBD();   
    $conn = $BD->getConexion();
       
    $stmt = $conn->prepare('SELECT * FROM pelis');
    $stmt->setFetchMode(PDO::FETCH_ASSOC);   
    $stmt->execute();
    $datos = $stmt->fetchAll();
        
    $BD->cerrarConexion();
        
    return $datos;   
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplicación</title>
</head>

<body>
    <a href="cerrarsesion.php">Cerrar Sesión</a>
</body>

</html>