<?php
    session_start();

    if (!isset( $_SESSION['usuario'])) {
        header('Location: login.php');
    }
    echo "ID: ".$_GET['id']."<br>";
    echo "NOMBRE: ".$_GET['nom']."<br>";
    echo "AÑO: ".$_GET['anio']."<br>";
    echo "<img src='./img/".$_GET['img']."' style='width:100px; heigth:100px'/><br>";
    echo "<button>".$_GET['boton']."</button>";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar</title>
</head>
<body>
</body>
</html>