<?php

// Parámetros acceso a una BD
define('HOST', 'localhost');
define('BD', 'examenextraord');
define('USER', 'dwes');
define('PASSWORD', 'dwes');
define('CHARSET', 'utf8');

?>