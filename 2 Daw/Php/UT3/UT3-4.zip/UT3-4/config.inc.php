<?php

$credenciales = array(
    'ana' => 'a4a97ffc170ec7ab32b85b2129c69c50',
    'jose' => '10dea63031376352d413a8e530654b8b',
    'marga' => '35559e8b5732fbd5029bef54aeab7a21',
    'anton' => 'C707dce7b5a990e349c873268cf5a968'
  );


