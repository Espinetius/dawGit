<!DOCTYPE html>

<html>
    <head> 
        <meta charset="utf-8"/>
        <title>Ejer-4 Bienvenida</title>
    </head> 
    <body bgcolor="lightgreen"> 
        <h3>BIENVENIDO</h3>    
        <a href='Ejer-3.php'>Regresar</a>
    </body>
</html>