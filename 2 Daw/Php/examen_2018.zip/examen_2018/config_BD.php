<?php

    define('HOST', 'localhost');
    define('BD', 'exrecup1eval');
    define('USER', 'dwes');
    define('PASSWORD', 'dwes');
    define('CHARSET', 'utf8');

?>