<?php

// Parámetros acceso a una BD
define('HOST', 'localhost');
define('BD', 'laBD');
define('USER', 'dwes');
define('PASSWORD', 'dwes');
define('CHARSET', 'utf8');

?>

